Data Structures and Algorithms. It includes implementations of the main Algorithms and Data Structures such as Array List,
Linked List, Doubly-linked List, CircularSingly-linked List, Stack, Queue, Map, TreeMap, HashMap, Trees, BST etc.
Analysis of Algorithms and different interview questions. 
