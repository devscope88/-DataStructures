package com.datastructure.ds.interview.bigo;

import javax.xml.soap.Node;

// O(N)
// Sums the values of all the nodes in a balanced binary search tree
//public class BinarySum {
//    public int sum(Node node) {
//        if (node == null) {
//            return 0;
//        }
//        return sum(node.left) + node.value + sum(node.right);
//    }
//}
