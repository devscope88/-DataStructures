//package com.datastructure.ds.interview.bigo.bigoprobl;
//
//// O(b log b  +  a log b)
//public class Intersection {
//    public static void main(String[] args) {
//        int[] a = {1,2,3,4,5};
//        int[] b = {6,2,7,4,8};
//    }
//
//    int intersection1(int[] a, int[] b) {
//        mergesort(b);
//        int intersect = 0;
//
//        for (int x : a) {
//            if (binarySearch(b, x) >= 0) {
//                intersect++;
//            }
//        }
//        return intersect;
//    }
//}
