package com.datastructure.ds.interview.bit;

// checks if n is a power of 2(or if n is 0)
public class Debugger {

    int n = 0;
    boolean a = ((n & (n - 1)) == 0);
}
