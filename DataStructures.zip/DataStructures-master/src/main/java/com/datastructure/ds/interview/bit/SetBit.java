package com.datastructure.ds.interview.bit;

public class SetBit {

    int setBit(int num, int i) {
        return num | (1 << i);
    }
}
