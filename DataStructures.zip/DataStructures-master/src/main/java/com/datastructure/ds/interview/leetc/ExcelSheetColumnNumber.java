package com.datastructure.ds.interview.leetc;

public class ExcelSheetColumnNumber {

    public int titleToNumber(String s) {
        int i = 0;
        for(; i < 3;i++) {
            System.out.println(i);
i++;
        }

        return 0;
    }
}
